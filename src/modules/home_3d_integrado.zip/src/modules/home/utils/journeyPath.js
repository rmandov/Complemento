import { CatmullRomCurve3, Vector3 } from 'three'

/**
 * Puntos proporcionales al área visible de la cámara.
 * Un único circuito cerrado sirve para 1, 3, 5 o N etapas.
 * No se debe añadir un nodo a la curva por cada etapa del JSON.
 *
 * X e Y son factores de semiancho y semialto ([-1, 1]); Z está en unidades 3D.
 * Los puntos están mayoritariamente a la derecha para dejar espacio al texto.
 */
// MODIFICAR AQUÍ PARA CAMBIAR EL RECORRIDO
export const JOURNEY_PATH_POINTS = [
  [0.66, 0.25, 0.15],
  [0.78, 0.08, -0.05],
  [0.64, -0.24, 0.30],
  [0.35, -0.33, 0.48],
  [0.22, -0.04, 0.17],
  [0.34, 0.31, -0.30],
]

export function createJourneyPath({ halfWidth, halfHeight, mobile = false, closed = true }) {
  const points = JOURNEY_PATH_POINTS.map(([x, y, z]) => new Vector3(
    (mobile ? (x - 0.5) * 1.5 : x) * halfWidth,
    (mobile ? y * 0.55 + 0.48 : y) * halfHeight,
    z,
  ))
  return new CatmullRomCurve3(points, closed, 'centripetal', 0.5)
}

/**
 * Distribuye todas las etapas a intervalos equidistantes del circuito.
 * El último punto se sitúa ANTES de 1, para evitar un salto al punto inicial.
 */
export function journeyCurveProgress(scrollProgress, stageCount) {
  if (stageCount <= 1) return 0
  const normalized = Math.max(0, Math.min(1, scrollProgress))
  return normalized * (stageCount - 1) / stageCount
}

export function stageScrollProgress(index, stageCount) {
  if (stageCount <= 1) return 0
  return Math.max(0, Math.min(stageCount - 1, index)) / (stageCount - 1)
}

export function stageIndexAtProgress(scrollProgress, stageCount) {
  if (stageCount <= 1) return 0
  return Math.max(0, Math.min(stageCount - 1, Math.round(scrollProgress * (stageCount - 1))))
}
