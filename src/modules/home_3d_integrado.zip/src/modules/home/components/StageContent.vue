<script setup>
defineProps({
  stage: { type: Object, default: null },
  number: { type: Number, default: 1 },
  total: { type: Number, default: 1 },
})
</script>

<template>
  <div class="stage-content" aria-live="polite" aria-atomic="true">
    <Transition name="stage-fade" mode="out-in">
      <article v-if="stage" :key="stage.id" class="stage-content__panel">
        <p class="stage-content__eyebrow">Recorrido {{ number }} / {{ total }}</p>
        <h2 class="stage-content__title">{{ stage.titulo }}</h2>
        <p class="stage-content__text">{{ stage.texto1 }}</p>
        <p class="stage-content__text">{{ stage.texto2 }}</p>
      </article>
    </Transition>
  </div>
</template>

<style scoped>
.stage-content {
  position: absolute;
  z-index: 2;
  left: clamp(190px, 19%, 280px);
  bottom: clamp(26px, 8%, 105px);
  width: min(39%, 430px);
  pointer-events: none;
}
.stage-content__panel {
  border: 1px solid rgb(147 167 199 / 24%);
  border-radius: 22px;
  padding: clamp(19px, 2.4vw, 32px);
  background: rgb(255 255 255 / 90%);
  box-shadow: 0 14px 50px rgb(53 77 115 / 9%);
  backdrop-filter: blur(12px);
}
.stage-content__eyebrow {
  margin: 0 0 10px;
  color: #53719b;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  font-size: 0.72rem;
  font-weight: 700;
}
.stage-content__title {
  font-family: NotoSansBold, NotoSans, sans-serif;
  font-size: clamp(1.4rem, 1.6vw + 0.6rem, 2.15rem);
  margin: 0 0 14px;
  line-height: 1.15;
  color: #172b49;
}
.stage-content__text {
  color: #344762;
  line-height: 1.55;
  font-size: clamp(0.9rem, 0.5vw + 0.75rem, 1.05rem);
  margin: 0 0 11px;
}
.stage-content__text:last-child { margin-bottom: 0; }
.stage-fade-enter-active, .stage-fade-leave-active {
  transition: opacity 230ms ease, transform 230ms ease;
}
.stage-fade-enter-from { opacity: 0; transform: translateY(11px); }
.stage-fade-leave-to { opacity: 0; transform: translateY(-11px); }
@media (max-width: 1023px) {
  .stage-content { left: 23%; width: min(51%, 450px); }
}
@media (max-width: 767px) {
  .stage-content {
    left: 14px; right: 14px; width: auto;
    bottom: 15px;
  }
  .stage-content__panel { padding: 18px; border-radius: 17px; }
  .stage-content__title { font-size: clamp(1.35rem, 5vw, 1.7rem); margin-bottom: 8px; }
  .stage-content__text { font-size: 0.88rem; line-height: 1.42; margin-bottom: 6px; }
}
@media (max-height: 560px) {
  .stage-content { bottom: 8px; }
  .stage-content__panel { padding: 12px 15px; }
  .stage-content__eyebrow { margin-bottom: 4px; }
  .stage-content__title { margin-bottom: 4px; }
  .stage-content__text { line-height: 1.3; }
}
@media (prefers-reduced-motion: reduce) {
  .stage-fade-enter-active, .stage-fade-leave-active { transition: none; }
}
</style>
