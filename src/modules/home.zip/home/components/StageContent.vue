<script setup>
defineProps({
  stage: { type: Object, default: null },
  number: { type: Number, default: 1 },
  total: { type: Number, default: 1 },
})
</script>

<template>
  <div class="stage-content" aria-live="polite" aria-atomic="true">
    <Transition name="stage-rise" mode="out-in" appear>
      <article v-if="stage" :key="stage.id" tabindex="0"
        :aria-label="`Etapa ${number}: ${stage.titulo}`"
        :class="['stage-content__panel', number % 2 === 1
          ? 'stage-content__panel--left' : 'stage-content__panel--right']">
        <p class="stage-content__eyebrow">Etapa {{ number }} / {{ total }}</p>
        <h2 class="stage-content__title">{{ stage.titulo }}</h2>
        <p v-if="stage.texto1" class="stage-content__text">{{ stage.texto1 }}</p>
        <p v-if="stage.texto2" class="stage-content__text">{{ stage.texto2 }}</p>
      </article>
    </Transition>
  </div>
</template>

<style scoped>
.stage-content { position: absolute; inset: 0; z-index: 2; pointer-events: none; }
.stage-content__panel {
  position: absolute;
  bottom: clamp(24px, 8%, 70px);
  width: min(37%, 430px);
  max-height: calc(100% - 32px);
  box-sizing: border-box;
  border: 1px solid #e1e8f2;
  border-radius: 18px;
  padding: clamp(18px, 2.1vw, 30px);
  background: rgb(255 255 255 / 95%);
  box-shadow: 0 12px 40px rgb(53 77 115 / 6%);
  pointer-events: auto;
  overflow-y: auto;
  scrollbar-width: thin;
  overscroll-behavior: auto;
}
.stage-content__panel--left { left: clamp(200px, 21%, 300px); right: auto; }
.stage-content__panel--right { right: clamp(20px, 4%, 70px); left: auto; }
.stage-content__panel:focus-visible { outline: 2px solid #3075ed; outline-offset: 3px; }
.stage-content__eyebrow { margin: 0 0 10px; color: #53719b; text-transform: uppercase; letter-spacing: 0.1em; font-size: 0.75rem; font-weight: 700; }
.stage-content__title { font-family: NotoSansBold, NotoSans, sans-serif; font-size: clamp(1.35rem, 1.6vw + 0.5rem, 2rem); margin: 0 0 14px; line-height: 1.2; color: #172b49; }
.stage-content__text { color: #344762; line-height: 1.55; font-size: clamp(0.95rem, 0.5vw + 0.7rem, 1.05rem); margin: 0 0 11px; }
.stage-content__text:last-child { margin-bottom: 0; }
.stage-rise-enter-active,
.stage-rise-leave-active { transition: opacity 0.4s ease, transform 0.6s cubic-bezier(0.22, 1, 0.36, 1); }
/* Todas las etapas entran desde abajo, independientemente del lado del panel. */
.stage-rise-enter-from { opacity: 0; transform: translateY(42px); }
.stage-rise-leave-to { opacity: 0; transform: translateY(-18px); }
@media (max-width: 1023px) and (min-width: 768px) {
  .stage-content__panel { width: 48%; padding: 20px; }
  .stage-content__panel--left { left: 23%; }
  .stage-content__panel--right { right: 4%; }
}
@media (max-width: 767px) {
  .stage-content__panel { width: auto; bottom: 16px; max-height: 52%; padding: 16px; border-radius: 14px; }
  .stage-content__panel--left,
  .stage-content__panel--right { left: 76px; right: 12px; }
  .stage-content__eyebrow { font-size: 0.75rem; margin-bottom: 8px; }
  .stage-content__title { font-size: clamp(1.15rem, 4.3vw, 1.6rem); margin-bottom: 10px; }
  .stage-content__text { font-size: 0.9rem; line-height: 1.45; }
}
@media (max-height: 500px) {
  .stage-content__panel { bottom: 8px; padding: 12px; max-height: calc(100% - 16px); }
  .stage-content__eyebrow { margin-bottom: 4px; }
  .stage-content__title { font-size: 1.1rem; margin-bottom: 6px; }
  .stage-content__text { font-size: 0.85rem; line-height: 1.35; }
}
@media (prefers-reduced-motion: reduce) {
  .stage-rise-enter-active,
  .stage-rise-leave-active { transition: none; }
}
</style>
